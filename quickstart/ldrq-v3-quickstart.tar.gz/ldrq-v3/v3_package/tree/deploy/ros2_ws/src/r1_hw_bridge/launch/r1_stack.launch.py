"""Bring up bridge + policy wired together.

USE THIS, not the two individual launch files, whenever both nodes run.

Each node names its topics under its own namespace (`~/obs` is
`/r1_hw_bridge/obs` for the bridge but `/r1_policy_node/obs` for the policy), so
without the remappings below the two nodes come up, log happily, and never
exchange a single message. The failure is silent in both directions:

  * the policy node waits on ~/obs forever and reports "filling observation
    history" once a second, which looks like a warm-up rather than a fault;
  * the bridge's ~/resume path publishes ~/policy_reset into the void, so an
    outage recovery would resume with a history straddling the gap -- exactly
    the out-of-distribution restart the design exists to prevent.

Output is OFF by default. Turning it on is a separate, deliberate act.
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

BRIDGE = "r1_hw_bridge"
POLICY = "r1_policy_runner"


def generate_launch_description():
    policy_params = os.path.join(
        get_package_share_directory(POLICY), "config", "policy_interface.yaml")
    bridge_params = os.path.join(
        get_package_share_directory(BRIDGE), "config", "bridge.yaml")

    args = [
        DeclareLaunchArgument("engine", description="absolute path to the .plan"),
        DeclareLaunchArgument("iface", default_value="eth10"),
        DeclareLaunchArgument("enable_output", default_value="false"),
        DeclareLaunchArgument("kp_scale", default_value="1.0"),
        DeclareLaunchArgument("kd_scale", default_value="1.0"),
        # Overridable so a degrade can be provoked on demand: set it above the
        # real observation rate and the guard must trip. Without it on the
        # command line the only way to exercise the rate guard is to edit
        # bridge.yaml, and a fault injection you forget to revert is worse than
        # one you cannot run.
        DeclareLaunchArgument("min_control_rate_hz", default_value="45.0"),
        # V3: the proximity reflex, off unless asked for (it needs r1_perception
        # running: without its frames forward walking is blocked). reflex_log: a
        # path for one CSV line per control step.
        DeclareLaunchArgument("reflex_enable", default_value="false"),
        DeclareLaunchArgument("reflex_log", default_value=""),
        # V3 dance: the second policy. Off unless asked for, and only with the reflex.
        # dance_engine: the dance policy's .plan; dance_reference: its dance_ref.bin.
        DeclareLaunchArgument("dance_enable", default_value="false"),
        DeclareLaunchArgument("dance_engine", default_value=""),
        DeclareLaunchArgument("dance_reference", default_value=""),
    ]

    bridge = Node(
        package=BRIDGE, executable="r1_hw_bridge_node", name="r1_hw_bridge",
        output="screen", emulate_tty=True,
        parameters=[bridge_params, {
            "iface": LaunchConfiguration("iface"),
            "enable_output": LaunchConfiguration("enable_output"),
            "kp_scale": LaunchConfiguration("kp_scale"),
            "kd_scale": LaunchConfiguration("kd_scale"),
            "min_control_rate_hz": LaunchConfiguration("min_control_rate_hz"),
            "reflex_enable": LaunchConfiguration("reflex_enable"),
            "reflex_log": LaunchConfiguration("reflex_log"),
            "dance_enable": LaunchConfiguration("dance_enable"),
        }],
        remappings=[
            ("joint_target", "/r1_policy_node/joint_target"),
            ("action", "/r1_policy_node/action"),
            ("dance_joint_target", "/r1_policy_node/dance_joint_target"),
            ("dance_action", "/r1_policy_node/dance_action"),
        ],
    )

    policy = Node(
        package=POLICY, executable="r1_policy_node", name="r1_policy_node",
        output="screen", emulate_tty=True,
        parameters=[policy_params, {
            "engine_path": LaunchConfiguration("engine"),
            "dance_engine_path": LaunchConfiguration("dance_engine"),
            "dance_reference_path": LaunchConfiguration("dance_reference"),
            "mode": "subscribe",
        }],
        remappings=[
            ("~/obs", "/r1_hw_bridge/obs"),
            ("~/policy_reset", "/r1_hw_bridge/policy_reset"),
        ],
    )

    return LaunchDescription(args + [bridge, policy])
